public class SimpleArrayIntList {
   // fields
   
   // constructors    
   
   // accessors
   
   // mutators
   
   // toString
}
